echo "Main-Class: Game" > data/Manifest.txt
jar cfm ../SlimeRun.jar data/Manifest.txt *.class data images
#/* images/* images/back/* images/blocks/* images/green/slime.png

// Ajay Jain
// September 24, 2012

import java.lang.Math;

public class HelloWorld {

	public static void main (String args[]) {
		Chromosome chromo = new Chromosome(12);
		chromo.calcCost("Hello, World!");
		System.out.printf("%s (%d)", chromo.code, chromo.cost);
	}
}

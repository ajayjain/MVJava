// Ajay Jain
// September 24, 2012
// Chromosome.java
// Chromosome for genetic algorithm

import java.lang.Math;

public class Chromosome {
	public String code;
	public int cost = 9999;
	
	public String random(int length) {
		while (length>0) {
			int rand = (int) (Math.random()*128);
			this.code += (char) (rand >= 32 ? rand : rand+32);
			length--;
		}
		this.code = this.code.substring(4); // null shows up at the start for some reason
		return this.code;
	}
	
	public int calcCost(String compareTo) {
		if (compareTo.length() < this.code.length()) throw new Error("calcCost param compareTo is too short "+this.code+" vs "+compareTo);
		int total = 0;
		for (int i = 0, _len = this.code.length(); i < _len; i++) {
			total += (int) this.code.charAt(i) - (int) compareTo.charAt(i);
		}
		this.cost = total;
		return total;
	}
	
	public ArrayList crossOver(Chromosome chromo) {
		return new ArrayList(2);
	}
	
	Chromosome(String code) {
		this.code = code;
	}
	Chromosome(int length) {
		this.code = this.random(length);
	}
}
